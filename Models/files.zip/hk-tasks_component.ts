import {
  Component,
  OnInit,
  OnDestroy,
  signal,
  computed,
  ViewChild,
  ElementRef,
  HostListener
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subscription, interval } from 'rxjs';

import { HkDashboardService } from '../hk-dashboard/hk-dashboard.service';
import { ToastService } from '../../../services/toast.service';
import { LoginContextService } from '../../../services/login-context.service';

import {  HkTask,  HkChecklistItem, HkNotification} from '../hk-dashboard/hk-dashboard.model';
import { AppConfigService } from '../../../services/app-config.service';

interface HkTaskVM {

  taskId: number;

  no: string;

  room: string;

  roomName: string;

  type: string;

  priority: string;

  status: string;

  staff: string | null;

  staffUserId: number | null;

  sla: number;

  triggeredDt: string;

  startedAt: string | null;

  completedAt: string | null;

  slaBreachFlag: string;

  checklist: {
    cd: string;
    nm: string;
    photoUrl?: string | null;
  }[];

  photoUrl: string | null;

  photoNotes: string | null;
}

@Component({
  selector: 'app-hk-tasks',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './hk-tasks.component.html',
  styleUrls: ['./hk-tasks.component.scss']
})
export class HkTasksComponent implements OnInit, OnDestroy {

  //=========================================================
  // SIGNALS
  //=========================================================

  assignedTasks = signal<HkTaskVM[]>([]);

  checklistState =
    signal<Record<string, Record<string, boolean>>>({});

  // FIX: these were plain fields. filteredTasks below is a computed()
  // signal, which only re-evaluates when a SIGNAL it reads changes —
  // reading a plain property does not register as a dependency. So
  // picking a different "Type" or clicking "Sort by SLA" updated these
  // values but never actually triggered filteredTasks to re-run; the
  // list only appeared to update by coincidence whenever assignedTasks
  // happened to refresh for an unrelated reason. Now signals, so both
  // controls correctly re-filter/re-sort immediately.
  selectedType = signal('');

  sortBySLA = signal(false);

  showCompleteModal = signal(false);

  currentTask = signal<HkTaskVM | null>(null);

  private refreshTick = signal(0);

  private timerSub?: Subscription;
  private notifPollSub?: Subscription;

  notifications = signal<HkNotification[]>([]);
  showNotifications = signal(false);
  unreadCount = computed(() => this.notifications().filter(n => n.isRead === 'N').length);

  // NEW: reference to the bell + dropdown wrapper, used by the
  // document-click listener below to close the panel when the person
  // clicks anywhere outside it.
  @ViewChild('notifWrapper') notifWrapper?: ElementRef<HTMLElement>;

  // ==========================================
  // NEW: mandatory-photo-per-checklist-item flow. This is now the ONLY
  // photo flow on this page — the old task-level "Photo Proof" button
  // and modal were removed since every checklist item already carries
  // its own mandatory photo, making a separate whole-task photo
  // redundant.
  // ==========================================

  showItemPhotoModal = signal(false);
  currentChecklistItem = signal<{ cd: string; nm: string; photoUrl?: string | null } | null>(null);
  // FIX: converted to signals. selectedItemPhoto/itemPhotoPreview used
  // to be plain fields, and the button reflecting them only refreshed
  // once some browser event happened to run inside Angular's zone
  // (e.g. a click) — which is why "Update Photo" only ever seemed to
  // appear while the mouse was actively interacting with the page.
  // Signals notify Angular's rendering pipeline directly and don't
  // depend on NgZone/event timing at all, so this is fixed regardless
  // of which async API set the value.
  itemPhotoPreview = signal<string | ArrayBuffer | null>(null);
  private selectedItemPhoto = signal<File | null>(null);
  @ViewChild('itemVideo')
  itemVideo!: ElementRef<HTMLVideoElement>;
  private itemMediaStream!: MediaStream;

  //=========================================================
  // CONSTRUCTOR
  //=========================================================

  constructor(
    private hk: HkDashboardService,
    private toast: ToastService,
    private loginContext: LoginContextService,
     private config: AppConfigService
  ) { }


  // ==========================================
  // API URL
  // ==========================================

  private get apiUrl(): string {
    return `${this.config.apiBaseUrl}`;
  }
  //=========================================================
  // INIT
  //=========================================================

  ngOnInit(): void {

    this.loadTasks();
    this.loadNotifications();

    this.timerSub =
      interval(1000).subscribe(() => {

        this.refreshTick.update(v => v + 1);

      });

    // NEW: keep the notification badge current without requiring a
    // manual page refresh.
    this.notifPollSub = interval(30000).subscribe(() => this.loadNotifications());

  }

  //=========================================================
  // NOTIFICATIONS
  //=========================================================

  loadNotifications(): void {
    const login = this.loginContext.getContext();
    this.hk.getMyNotifications(login.sessionId).subscribe({
      next: (list) => this.notifications.set(list),
      error: () => { /* silent — non-critical */ }
    });
  }

  toggleNotifications(): void {
    this.showNotifications.set(!this.showNotifications());
  }

  // FIX: previously the only way to close the notifications dropdown
  // was to click the bell again — clicking anywhere else on the page
  // left it open, covering whatever was underneath. This closes it on
  // any click outside the bell/panel, matching normal dropdown
  // behavior.
  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    if (!this.showNotifications()) {
      return;
    }
    const wrapper = this.notifWrapper?.nativeElement;
    if (wrapper && !wrapper.contains(event.target as Node)) {
      this.showNotifications.set(false);
    }
  }

  markNotificationRead(notificationId: number): void {
    const login = this.loginContext.getContext();
    this.hk.markNotificationRead(login.sessionId, notificationId).subscribe({
      next: () => this.loadNotifications(),
      error: () => this.toast.show('Failed to update notification', 'warn')
    });
  }

  markAllNotificationsRead(): void {
    const login = this.loginContext.getContext();
    this.hk.markNotificationRead(login.sessionId).subscribe({
      next: () => this.loadNotifications(),
      error: () => this.toast.show('Failed to update notifications', 'warn')
    });
  }

  ngOnDestroy(): void {

    this.timerSub?.unsubscribe();
    this.notifPollSub?.unsubscribe();

    if (this.itemMediaStream) {
      this.itemMediaStream.getTracks().forEach(track => track.stop());
    }

  }

  //=========================================================
  // LOAD TASKS
  //=========================================================

  private loadTasks(): void {

    const login = this.loginContext.getContext();

    this.hk.getMyTasks(login.sessionId)
      .subscribe({

        next: (tasks: HkTask[]) => {

          this.assignedTasks.set(

            tasks.map(t => this.toTaskVM(t))

          );

        },

        error: () => {

          this.toast.show(
            'Failed to load assigned tasks',
            'warn'
          );

        }

      });

  }

  //=========================================================
  // VIEW MODEL
  //=========================================================

  private toTaskVM(task: HkTask): HkTaskVM {

    return {

      taskId: task.taskId,

      no: task.taskNo,

      room: task.roomNo,

      roomName: task.roomName,

      type: task.taskType,

      priority: task.priority,

      status: task.status,

      staff: task.assignedStaffName ?? null,

      staffUserId: task.assignedUserId ?? null,

      sla: task.slaMinutes,

      triggeredDt: task.triggeredDt,

      startedAt: task.startedAt,

      completedAt: task.completedAt,

      slaBreachFlag: task.slaBreachFlag,

      checklist: [],
      photoUrl: task.photoUrl,
      photoNotes: task.photoNotes

    };

  }

  //=========================================================
  // FILTERED TASKS
  //=========================================================

  filteredTasks = computed(() => {

    let tasks = [...this.assignedTasks()];

    if (this.selectedType()) {

      tasks = tasks.filter(

        x => x.type == this.selectedType()

      );

    }

    if (this.sortBySLA()) {

      tasks.sort(

        (a, b) =>

          this.slaPercentage(b) -

          this.slaPercentage(a)

      );

    }

    return tasks;

  });

  //=========================================================
  // COUNTERS
  //=========================================================

  pendingCount = computed(() =>
    this.assignedTasks()
      .filter(x => x.status == 'ASSIGNED').length
  );

  inProgressCount = computed(() =>
    this.assignedTasks()
      .filter(x => x.status == 'IN_PROGRESS').length
  );

  readyCount = computed(() =>
    this.assignedTasks()
      .filter(x => x.status == 'INSPECTING').length
  );

  criticalCount = computed(() =>
    this.assignedTasks()
      .filter(x => this.slaPercentage(x) >= 90).length
  );

  //=========================================================
  // FILTER
  //=========================================================

  filterTasks(): void {

    // handled by computed()

  }

  toggleSort(): void {

    this.sortBySLA.set(!this.sortBySLA());

  }
    //=========================================================
  // LOAD CHECKLIST
  //=========================================================

  loadChecklist(task: HkTaskVM): void {

    if (task.checklist.length > 0) {
      return;
    }

    const login = this.loginContext.getContext();

    this.hk.getTaskChecklist(
      login.sessionId,
      task.taskId
    )
    .subscribe({

      next: (items: HkChecklistItem[]) => {

        task.checklist = items.map(x => ({
          cd: x.itemCd ?? '',
          nm: x.itemNm ?? '',
          photoUrl: x.photoUrl ?? null
        }));

        const state = {
          ...this.checklistState()
        };

        state[task.no] = {};

        items.forEach(x => {

          state[task.no][x.itemNm ?? ''] =
            x.isComplete === 'Y';

        });

        this.checklistState.set(state);

        this.assignedTasks.set([
          ...this.assignedTasks()
        ]);

      },

      error: () => {

        this.toast.show(
          'Failed to load checklist',
          'warn'
        );

      }

    });

  }

  //=========================================================
  // CHECKLIST — mandatory photo per item
  // FIX: an item is no longer toggled directly from the card. Tapping an
  // unchecked item opens the photo capture flow scoped to that item;
  // the item only gets marked done once a photo has actually been
  // uploaded for it (see submitItemPhoto()). Tapping an already-done
  // item does nothing here — undoing a photographed, completed item is
  // a supervisor action, not a casual tap.
  //=========================================================

  // FIX (points 2 & 3): staff previously could never uncheck a
  // completed item at all — tapping it only opened the view/retake
  // photo modal. Now, for as long as the task is still being actively
  // worked (ASSIGNED / IN_PROGRESS — see isChecklistEditable()), items
  // can be freely checked and unchecked any number of times; checking
  // an item still requires a fresh mandatory photo each time. Once
  // "Mark Room Cleaned" is confirmed and the task moves to INSPECTING,
  // the checklist locks — tapping a done item then falls back to a
  // view-only look at the submitted photo instead of unchecking it.
  onChecklistItemTap(task: HkTaskVM, item: { cd: string; nm: string; photoUrl?: string | null }, event: MouseEvent): void {

    event.stopPropagation();

    const editable = this.isChecklistEditable(task);

    if (this.isItemDone(task.no, item.nm)) {
      if (editable) {
        this.uncheckItem(task, item);
      } else {
        this.viewChecklistItemPhoto(task, item, event);
      }
      return;
    }

    if (!editable) {
      this.toast.show('This task has already been submitted for inspection — the checklist can no longer be edited.', 'warn');
      return;
    }

    this.currentTask.set(task);
    this.currentChecklistItem.set(item);
    this.itemPhotoPreview.set(null);
    this.selectedItemPhoto.set(null);
    this.showItemPhotoModal.set(true);

    setTimeout(() => this.openItemCamera(), 200);
  }

  // NEW: whether the checklist is still open for editing on this task —
  // true while staff are actively working it, false once it's been
  // submitted for supervisor review (or beyond).
  isChecklistEditable(task: HkTaskVM): boolean {
    return task.status === 'ASSIGNED' || task.status === 'IN_PROGRESS';
  }

  // NEW: same check, but for whatever task/item is currently open in
  // the photo modal — used to hide Retake/Update controls once the
  // checklist has locked.
  isCurrentItemEditable(): boolean {
    const task = this.currentTask();
    return !!task && this.isChecklistEditable(task);
  }

  // NEW: reverts a checked item back to incomplete. A plain toggle —
  // no photo needed to uncheck, only to check. Optimistic with
  // rollback, matching the pattern used elsewhere on this page.
  uncheckItem(task: HkTaskVM, item: { cd: string; nm: string; photoUrl?: string | null }): void {

    const login = this.loginContext.getContext();

    const state = { ...this.checklistState() };
    if (!state[task.no]) state[task.no] = {};
    state[task.no][item.nm] = false;
    this.checklistState.set(state);

    this.hk.toggleChecklistItem({
      sessionId: login.sessionId,
      taskId: task.taskId,
      itemCd: item.cd,
      isComplete: false
    }).subscribe({
      error: () => {
        const rollback = { ...this.checklistState() };
        if (!rollback[task.no]) rollback[task.no] = {};
        rollback[task.no][item.nm] = true;
        this.checklistState.set(rollback);
        this.toast.show('Failed to uncheck item', 'warn');
      }
    });
  }

  // NEW: opens the same item-photo modal, but pre-loaded with the
  // already-uploaded photo shown large. Since itemPhotoPreview is
  // already truthy, the modal opens straight into "here's the photo,
  // tap Retake to replace it" — no camera stream is started until the
  // person actually taps Retake.
  viewChecklistItemPhoto(task: HkTaskVM, item: { cd: string; nm: string; photoUrl?: string | null }, event: MouseEvent): void {
    event.stopPropagation();

    if (!item.photoUrl) {
      return;
    }

    this.currentTask.set(task);
    this.currentChecklistItem.set(item);
    this.itemPhotoPreview.set(this.itemPhotoFullUrl(item.photoUrl));
    this.selectedItemPhoto.set(null);
    this.showItemPhotoModal.set(true);
  }

  // NEW: whether the item currently open in the photo modal is already
  // complete — used by the template to switch the modal between
  // "capture a required photo" wording and "here's the proof photo"
  // wording.
  isCurrentItemDone(): boolean {
    const task = this.currentTask();
    const item = this.currentChecklistItem();
    if (!task || !item) {
      return false;
    }
    return this.isItemDone(task.no, item.nm);
  }

  // NEW: builds the full displayable URL for a checklist item's
  // uploaded proof photo (photoUrl from the API is a relative path).
  // NEW: template-safe check for whether a fresh photo was captured in
  // this modal session (selectedItemPhoto itself stays private).
  hasNewItemCapture(): boolean {
    return !!this.selectedItemPhoto();
  }

  itemPhotoFullUrl(url: string | null | undefined): string {
    if (!url) {
      return '';
    }
    return `${this.apiUrl}${url}`;
  }

  async openItemCamera(): Promise<void> {
    try {
      this.itemMediaStream = await navigator.mediaDevices.getUserMedia({ video: true });

      setTimeout(() => {
        if (this.itemVideo) {
          this.itemVideo.nativeElement.srcObject = this.itemMediaStream;
        }
      }, 200);
    } catch (err) {
      console.error('Camera Error:', err);
      this.toast.show('Unable to access camera.', 'warn');
    }
  }

  captureItemImage(): void {

    const video = this.itemVideo.nativeElement;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      return;
    }
    ctx.drawImage(video, 0, 0);

    const dataUrl = canvas.toDataURL('image/jpeg');
    this.itemPhotoPreview.set(dataUrl);

    // FIX: previously used canvas.toBlob(cb, ...) — that callback runs
    // outside Angular's zone (it isn't a zone-patched API like
    // Promises/timers are), so selectedItemPhoto WAS being set
    // correctly, but the "Update Photo" button's [disabled] binding
    // didn't re-evaluate until some unrelated zone-patched event (a
    // mousedown, a click) forced change detection — which is exactly
    // why the button only ever flickered into view while the mouse was
    // actively pressed on the page. Deriving the File synchronously
    // from the dataURL (already computed synchronously above) removes
    // the async gap, AND both fields are now signals — writing them
    // notifies Angular's rendering pipeline directly, with no
    // dependency on NgZone/event timing at all.
    this.selectedItemPhoto.set(this.dataUrlToFile(dataUrl, 'ChecklistItemPhoto.jpg'));

    if (this.itemMediaStream) {
      this.itemMediaStream.getTracks().forEach(t => t.stop());
    }
  }

  private dataUrlToFile(dataUrl: string, filename: string): File {
    const parts = dataUrl.split(',');
    const mimeMatch = parts[0].match(/:(.*?);/);
    const mime = mimeMatch ? mimeMatch[1] : 'image/jpeg';
    const binary = atob(parts[1]);
    let len = binary.length;
    const bytes = new Uint8Array(len);
    while (len--) {
      bytes[len] = binary.charCodeAt(len);
    }
    return new File([bytes], filename, { type: mime });
  }

  retakeItemPhoto(): void {
    this.itemPhotoPreview.set(null);
    this.selectedItemPhoto.set(null);
    setTimeout(() => this.openItemCamera(), 200);
  }

  closeItemPhotoModal(): void {
    if (this.itemMediaStream) {
      this.itemMediaStream.getTracks().forEach(t => t.stop());
    }
    this.showItemPhotoModal.set(false);
    this.currentChecklistItem.set(null);
    this.itemPhotoPreview.set(null);
    this.selectedItemPhoto.set(null);
  }

  // FIX: this is the piece that makes the photo genuinely mandatory —
  // the checklist item is marked done ONLY after the photo upload
  // succeeds. If the upload fails, the item stays unchecked and the
  // modal stays open so staff can retry, instead of silently marking
  // it complete either way.
  submitItemPhoto(): void {

    const task = this.currentTask();
    const item = this.currentChecklistItem();

    if (!task || !item) {
      return;
    }

    const photo = this.selectedItemPhoto();

    if (!photo) {
      this.toast.show('Please capture a photo first.', 'warn');
      return;
    }

    const login = this.loginContext.getContext();

    const formData = new FormData();
    formData.append('sessionId', login.sessionId.toString());
    formData.append('taskId', task.taskId.toString());
    formData.append('itemCd', item.cd);
    formData.append('photo', photo);

    this.hk.uploadChecklistItemPhoto(formData).subscribe({

      next: (res: any) => {

        // FIX: response can come back as either the wrapped
        // ApiResponse<HkOperationResult> shape (data.photoUrl) or
        // already-unwrapped (photoUrl directly) — read defensively so
        // the thumbnail actually gets the URL either way.
        const uploadedUrl: string | null = res?.data?.photoUrl ?? res?.photoUrl ?? null;

        // Photo stored — now mark the item complete via the existing
        // toggle endpoint (unchanged, already worked correctly). This
        // is a no-op status-wise on retake since the item is already
        // complete, but it's cheap and keeps one code path for both.
        this.hk.toggleChecklistItem({
          sessionId: login.sessionId,
          taskId: task.taskId,
          itemCd: item.cd,
          isComplete: true
        }).subscribe({

          next: () => {
            const state = { ...this.checklistState() };
            if (!state[task.no]) state[task.no] = {};
            state[task.no][item.nm] = true;
            this.checklistState.set(state);

            // NEW: store the uploaded photo URL directly on the
            // checklist item so its thumbnail shows immediately,
            // without needing a full page refresh.
            if (uploadedUrl) {
              const checklistItem = task.checklist.find(ci => ci.cd === item.cd);
              if (checklistItem) {
                checklistItem.photoUrl = uploadedUrl;
              }
              this.assignedTasks.set([...this.assignedTasks()]);
            }

            this.toast.success('Photo saved — item marked complete.');
            this.closeItemPhotoModal();
          },

          error: () => {
            this.toast.show('Photo saved, but marking the item complete failed — please retry.', 'warn');
          }
        });
      },

      error: () => {
        this.toast.show('Photo upload failed — item was not marked complete.', 'warn');
      }
    });
  }

  //=========================================================
  // CHECKLIST HELPERS
  //=========================================================

  isItemDone(
    taskNo: string,
    itemName: string
  ): boolean {

    return this.checklistState()
      [taskNo]?.[itemName] ?? false;

  }

  getCompletedItems(
    taskNo: string
  ): number {

    const state =
      this.checklistState()[taskNo] || {};

    return Object
      .values(state)
      .filter(x => x)
      .length;

  }

  getChecklistProgress(
    taskNo: string
  ): number {

    const task =
      this.assignedTasks()
      .find(x => x.no == taskNo);

    if (!task) {
      return 0;
    }

    if (task.checklist.length == 0) {
      return 0;
    }

    return Math.round(

      this.getCompletedItems(taskNo)
      * 100
      / task.checklist.length

    );

  }

  //=========================================================
  // SLA
  //=========================================================

  private elapsedMinutes(
    task: HkTaskVM
  ): number {

    this.refreshTick();

    const triggered =
      new Date(task.triggeredDt)
      .getTime();

    return Math.max(

      0,

      Math.floor(

        (Date.now() - triggered)

        / 60000

      )

    );

  }
  private elapsedSeconds(task: HkTaskVM): number {

  this.refreshTick();

  const triggered =
      new Date(task.triggeredDt).getTime();

  return Math.max(
      0,
      Math.floor((Date.now() - triggered) / 1000)
  );

}
  elapsedDisplay(task: HkTaskVM): string {

    const elapsed = this.elapsedMinutes(task);

    return `${elapsed} min`;

  }

  
  elapsedTime(task: HkTaskVM): string {

    this.refreshTick();

    const triggered = new Date(task.triggeredDt).getTime();

    const elapsed = Math.max(
      0,
      Math.floor((Date.now() - triggered) / 1000)
    );

    const hrs = Math.floor(elapsed / 3600);
    const mins = Math.floor((elapsed % 3600) / 60);
    const secs = elapsed % 60;

    return `${hrs.toString().padStart(2, '0')}:${mins
      .toString()
      .padStart(2, '0')}:${secs
        .toString()
        .padStart(2, '0')}`;

  }
  targetTime(task: HkTaskVM): string {

    const hrs = Math.floor(task.sla / 60);

    const mins = task.sla % 60;

    return `${hrs.toString().padStart(2, '0')}:${mins
      .toString()
      .padStart(2, '0')}:00`;

  }
  slaPercentage(task: HkTaskVM): number {

    const elapsed = this.elapsedSeconds(task);

    const total = task.sla * 60;

    return Math.min(
      100,
      Math.round((elapsed / total) * 100)
    );

  }

  slaColor(task: HkTaskVM): string {

    const elapsed = this.elapsedSeconds(task);

    const total = task.sla * 60;

    const percentage = (elapsed / total) * 100;

    if (elapsed >= total || task.slaBreachFlag === 'Y') {

      return '#dc2626';     // Red

    }

    if (percentage >= 90) {

      return '#ea580c';     // Orange

    }

    if (percentage >= 70) {

      return '#ca8a04';     // Yellow

    }

    return '#16a34a';       // Green

  }
  slaStatus(task: HkTaskVM): string {

    const elapsed = this.elapsedSeconds(task);

    const total = task.sla * 60;

    const percentage = (elapsed / total) * 100;

    if (elapsed >= total || task.slaBreachFlag === 'Y') {

      return '🔴 SLA BREACHED';

    }

    if (percentage >= 90) {

      return '🟠 Critical';

    }

    if (percentage >= 70) {

      return '🟡 Approaching SLA';

    }

    return '🟢 Within SLA';

  }

  //=========================================================
  // LABELS
  //=========================================================

  // FIX: statuses were rendered as raw enum values (e.g. "IN_PROGRESS",
  // "FAILED_INSP") straight from the API instead of a readable label —
  // matches the labeling the dashboard already does via statusLabel().
  taskStatusLabel(status: string): string {
    const labels: Record<string, string> = {
      PENDING: 'Pending',
      ASSIGNED: 'Assigned',
      IN_PROGRESS: 'In Progress',
      INSPECTING: 'Inspecting',
      FAILED_INSP: 'Failed Inspection',
      READY: 'Ready'
    };
    return labels[status] || status;
  }

  taskTypeLabel(
    type: string
  ): string {

    const labels:
    Record<string, string> = {

      CHECKOUT_CLEAN:
      'Checkout Clean',

      QUICK_TURN:
      'Quick Turn',

      VIP_PREP:
      'VIP Clean',

      DEEP_CLEAN:
      'Deep Clean',

      SPOT_CLEAN:
      'Spot Clean',

      POST_MAINTENANCE:
      'Post Maintenance'

    };

    return labels[type] || type;

  }
    //=========================================================
  // COMPLETE TASK
  //=========================================================

  markRoomCleaned(task: HkTaskVM): void {

    this.currentTask.set(task);

    this.showCompleteModal.set(true);

  }

  confirmComplete(): void {

    const task = this.currentTask();

    if (!task) {
      return;
    }

    const login = this.loginContext.getContext();

    this.hk.completeTask({

      sessionId: login.sessionId,

      taskId: task.taskId

    }).subscribe({

      next: (result) => {

        this.toast.success(

          result.message ||

          `Room ${task.room} marked as cleaned.`

        );

        this.showCompleteModal.set(false);

        this.currentTask.set(null);
        this.checklistState.set({});

        this.loadTasks();

      },

      error: (err) => {

        this.toast.show(

          err?.error?.message ||

          'Failed to complete task',

          'warn'

        );

      }

    });

  }

  //=========================================================
  // NOTE: the old task-level "Photo Proof" button + modal (capturePhoto/
  // submitPhoto/openCamera/captureImage/retakePhoto/closePhotoModal)
  // were removed here. Every checklist item now has its own mandatory
  // photo (see the CHECKLIST — mandatory photo per item section above),
  // so a separate whole-task photo was redundant and has been dropped.
  //=========================================================

  closeCompleteModal(): void {

    this.showCompleteModal.set(false);

    this.currentTask.set(null);

  }

  //=========================================================
  // REQUEST NEW TASK
  //=========================================================

  requestNewTask(): void {

    this.toast.show(

      'Please contact your supervisor for a new assignment.',

      'ok'

    );

  }

  //=========================================================
  // CARD LOAD
  //=========================================================

  openTask(task: HkTaskVM): void {

    this.loadChecklist(task);

  }

}
